package com.adeel.adeeldemo.model

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
 class Beneficiary(
    @SerializedName("lastName"             ) var lastName             : String?             = null,
    @SerializedName("firstName"            ) var firstName            : String?             = null,
    @SerializedName("designationCode"      ) var designationCode      : String?             = null,
    @SerializedName("beneType"             ) var beneType             : String?             = null,
    @SerializedName("socialSecurityNumber" ) var socialSecurityNumber : String?             = null,
    @SerializedName("dateOfBirth"          ) var dateOfBirth          : String?             = null,
    @SerializedName("middleName"           ) var middleName           : String?             = null,
    @SerializedName("phoneNumber"          ) var phoneNumber          : String?             = null,
    @SerializedName("beneficiaryAddress"   ) var beneficiaryAddress   : BeneficiaryAddress? = BeneficiaryAddress()
): Parcelable {
    fun getDesignationTitle():String{
        return when(designationCode){
            "P" -> "Primary"
            else -> "Contingent"
        }
    }
    fun getDateOfBirthTitle():String{
        return "${dateOfBirth?.substring(0,2)}/${dateOfBirth?.substring(2,3)}/${dateOfBirth?.substring(3)}"
    }
}