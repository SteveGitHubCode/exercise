package com.adeel.adeeldemo.repo

import android.app.Application
import android.content.Context
import com.adeel.adeeldemo.R
import com.adeel.adeeldemo.model.Beneficiary
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import java.io.InputStream

class DataRepository(private val gson:Gson, private val context: Context) {
    suspend fun getBeneficiaries(): List<Beneficiary>{
        val inputStream: InputStream = context.resources.openRawResource(R.raw.beneficiaries)
        val jsonString = inputStream.bufferedReader().use { it.readText() }
        return gson.fromJson(jsonString,object : TypeToken<List<Beneficiary>>() {
        }.type)
    }
}