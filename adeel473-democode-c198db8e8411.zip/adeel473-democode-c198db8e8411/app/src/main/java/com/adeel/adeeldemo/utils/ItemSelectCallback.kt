package com.adeel.adeeldemo.utils

interface ItemSelectCallback<T> {
    fun onItemSelect(t: T)
}