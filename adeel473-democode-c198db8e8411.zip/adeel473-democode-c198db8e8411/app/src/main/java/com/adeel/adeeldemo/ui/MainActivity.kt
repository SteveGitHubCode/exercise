package com.adeel.adeeldemo.ui

import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.adeel.adeeldemo.R
import com.adeel.adeeldemo.databinding.ActivityMainBinding
import com.adeel.adeeldemo.ui.beneficieries.BeneficiaryListFragment
import com.adeel.adeeldemo.utils.NavigationUtils
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class MainActivity : AppCompatActivity(){
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        binding.lifecycleOwner = this
        onBackPressedDispatcher.addCallback(onBackPressedCallback)
        NavigationUtils.addFragment(true,supportFragmentManager,BeneficiaryListFragment.newInstance(), tag = "HOME")

    }

    override fun onDestroy() {
        super.onDestroy()
    }

    private val onBackPressedCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            //showing dialog and then closing the application..
            if (!NavigationUtils.onBackButton(supportFragmentManager)){
                finish()
            }
        }
    }
}