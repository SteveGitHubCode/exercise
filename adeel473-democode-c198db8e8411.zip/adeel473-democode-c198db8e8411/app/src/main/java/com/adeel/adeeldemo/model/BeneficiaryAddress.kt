package com.adeel.adeeldemo.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class BeneficiaryAddress (

  @SerializedName("firstLineMailing" ) var firstLineMailing : String? = null,
  @SerializedName("scndLineMailing"  ) var secondLineMailing  : String? = null,
  @SerializedName("city"             ) var city             : String? = null,
  @SerializedName("zipCode"          ) var zipCode          : String? = null,
  @SerializedName("stateCode"        ) var stateCode        : String? = null,
  @SerializedName("country"          ) var country          : String? = null

) : Parcelable