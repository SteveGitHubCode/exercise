package com.adeel.adeeldemo.utils

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.adeel.adeeldemo.R
import java.util.Stack

object NavigationUtils {
    var fragmentStack = Stack<Fragment>()

    fun addFragment(addToBackStack:Boolean,
                    manager: FragmentManager,
                    fragment: Fragment,
                    frameId: Int = R.id.container,
                    tag:String){

        val ft = manager.beginTransaction()
        ft.replace(frameId, fragment,tag);
//        ft.add(frameId, fragment,tag)

        if(addToBackStack) {
//            ft.addToBackStack(tag)
            fragmentStack.push(fragment);
        }
        ft.commit()
    }
    fun addFragment(addToBackStack:Boolean,
                    manager: FragmentManager,
                    fragment: Fragment,
                    frameId: Int = R.id.container,
                    tag:String,
                    frgToHide:Fragment){

        val ft = manager.beginTransaction()
        ft.replace(frameId, fragment,tag);

//        ft.add(frameId, fragment,tag)
        if(addToBackStack) {
//            ft.addToBackStack(tag)
            fragmentStack.push(fragment);
        }
//        ft.hide(frgToHide)

        ft.commit()
    }

    fun onBackButton(manager: FragmentManager): Boolean {
        if (!fragmentStack.empty())
            fragmentStack.pop()
        if (!fragmentStack.empty()) {
            val ft = manager.beginTransaction();
            val frg = fragmentStack.lastElement();
            ft.replace(R.id.container, frg);
            ft.commit()
            return true;
        }
        return false
    }
    fun replaceFragment(addToBackStack:Boolean,manager: FragmentManager,
                        fragment: Fragment,
                        frameId: Int = R.id.container,
                        tag:String){

        val ft = manager.beginTransaction()
        ft.replace(frameId, fragment,tag)
        if(addToBackStack) {
            ft.addToBackStack(tag)
        }
        ft.commit()
    }
    fun replaceFragment(manager: FragmentManager,
                                fragment: Fragment,
                        frameId: Int = R.id.container,
                                tag:String) {
        val backStateName = fragment.javaClass.name
        val fragmentPopped = manager.popBackStackImmediate(tag, 0)
        if (!fragmentPopped && manager.findFragmentByTag(tag) == null) { //fragment not in back stack, create it.
            val ft = manager.beginTransaction()
            ft.replace(frameId, fragment, tag)
            ft.addToBackStack(tag)
            ft.commit()
        }/*else if (tag.contentEquals(FragmentTags.FRAGMENT_LOC_TIMING)){
            (manager.findFragmentByTag(backStateName) as? LocationTimingsFragment)?.setScreen(1)
        }*/
    }
    fun replaceFragment(addToBackStack:Boolean,manager: FragmentManager,
                        fragment: Fragment,
                        frameId: Int = R.id.container,
                        tag:String,
                        clearStack:Boolean){

        if (clearStack) clearMyBackStack(manager)

        val ft = manager.beginTransaction()
        ft.replace(frameId, fragment,tag)
        if(addToBackStack) {
            ft.addToBackStack(tag)
        }

        ft.commit()
    }
    fun replaceFragment(addToBackStack:Boolean,manager: FragmentManager,
                        fragment: Fragment,
                        frameId: Int = R.id.container,
                        tag:String,
                        frg:Fragment){


        var ft = manager.beginTransaction()
        ft.remove(frg)
        ft.commit()
        manager.popBackStack()

        ft = manager.beginTransaction()
        ft.replace(frameId, fragment,tag)
        if(addToBackStack) {
            ft.addToBackStack(tag)
        }

        ft.commit()
    }
    private fun clearMyBackStack(manager: FragmentManager) {
        try {
            val count = manager.backStackEntryCount
            for (i in 0 until count) {
                manager.popBackStackImmediate()
            }
        }catch (e:Exception) {e.printStackTrace()}
    }

    fun hideFragment(frg: Fragment,manager: FragmentManager) {
        var ft = manager.beginTransaction()

        if(frg != null){
            ft.hide(frg)
            ft.commit()

        }
    }
}