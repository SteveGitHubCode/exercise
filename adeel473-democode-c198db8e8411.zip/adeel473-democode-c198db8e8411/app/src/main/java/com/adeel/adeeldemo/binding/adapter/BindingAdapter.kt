package com.adeel.adeeldemo.binding.adapter

import androidx.databinding.BindingAdapter
import androidx.recyclerview.widget.RecyclerView
import com.adeel.adeeldemo.model.Beneficiary
import com.adeel.adeeldemo.ui.beneficieries.BeneficiariesAdapter

@BindingAdapter("app:items")
fun setItems( listView: RecyclerView, items: List<Beneficiary>?) {
    items?.let {data ->
        listView.adapter?.let {
            (listView.adapter as BeneficiariesAdapter).submitList(data)
            return
        }
        listView.adapter = BeneficiariesAdapter(ArrayList(data))
    }
}