package com.adeel.adeeldemo.ui.beneficieries

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.adeel.adeeldemo.R
import com.adeel.adeeldemo.databinding.ItemBeneficeryBinding
import com.adeel.adeeldemo.model.Beneficiary
import com.adeel.adeeldemo.utils.ItemSelectCallback

class BeneficiariesAdapter(private val listItems:ArrayList<Beneficiary>): RecyclerView.Adapter<BeneficiariesAdapter.ViewHolder>() {
    var listener: ItemSelectCallback<Beneficiary>? = null

    @SuppressLint("NotifyDataSetChanged")
    fun submitList(listItems:List<Beneficiary>){
        this.listItems.clear()
        this.listItems.addAll(listItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding:ItemBeneficeryBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.context), R.layout.item_beneficery,parent,
            false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return listItems.count()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(beneficiary = listItems[position], listener)
    }

    class ViewHolder(val binding:ItemBeneficeryBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(beneficiary: Beneficiary,listener:ItemSelectCallback<Beneficiary>?){
            binding.root.setOnClickListener {
                listener?.onItemSelect(beneficiary)
            }
            binding.beneficery = beneficiary
            binding.executePendingBindings()
        }
    }
}