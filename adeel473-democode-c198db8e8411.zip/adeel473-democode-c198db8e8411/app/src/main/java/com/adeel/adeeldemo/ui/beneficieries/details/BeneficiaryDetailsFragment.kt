package com.adeel.adeeldemo.ui.beneficieries.details

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.adeel.adeeldemo.R
import com.adeel.adeeldemo.databinding.FragmentBenDetailBinding
import com.adeel.adeeldemo.databinding.FragmentHomeBinding
import com.adeel.adeeldemo.model.Beneficiary
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BeneficiaryDetailsFragment : Fragment(){
    private val viewModel: BeneficiaryDetailsViewModel by viewModels()

    lateinit var binding: FragmentBenDetailBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(layoutInflater, R.layout.fragment_ben_detail,container, false)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner
        binding.back.setOnClickListener {
            requireActivity().onBackPressedDispatcher.onBackPressed()
        }
        arguments?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                viewModel.beneficiary.postValue(it.getParcelable("ben",Beneficiary::class.java))
            }else{
                (it.getParcelable("ben") as? Beneficiary)?.let {b ->
                    viewModel.beneficiary.postValue(b)
                }
            }
        }
        return binding.root
    }

    companion object {
        @JvmStatic
        fun newInstance(ben:Beneficiary) =
            BeneficiaryDetailsFragment().apply {
                arguments = Bundle().apply {
                    putParcelable("ben",ben)
                }
            }
    }


}