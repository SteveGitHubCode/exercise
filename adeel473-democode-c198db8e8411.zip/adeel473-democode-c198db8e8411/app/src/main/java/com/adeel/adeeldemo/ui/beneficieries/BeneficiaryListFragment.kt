package com.adeel.adeeldemo.ui.beneficieries

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.adeel.adeeldemo.R
import com.adeel.adeeldemo.databinding.FragmentHomeBinding
import com.adeel.adeeldemo.model.Beneficiary
import com.adeel.adeeldemo.ui.beneficieries.details.BeneficiaryDetailsFragment
import com.adeel.adeeldemo.utils.ItemSelectCallback
import com.adeel.adeeldemo.utils.NavigationUtils
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BeneficiaryListFragment : Fragment(), ItemSelectCallback<Beneficiary> {
    private val viewModel: BeneficiaryViewModel by viewModels()

    lateinit var binding: FragmentHomeBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(layoutInflater, R.layout.fragment_home,container, false)
        binding.viewModel = viewModel
        binding.lifecycleOwner = viewLifecycleOwner


        val layoutManager = LinearLayoutManager(requireContext(),LinearLayoutManager.VERTICAL, false)
        binding.rv.layoutManager = layoutManager
        val ad = BeneficiariesAdapter(ArrayList())
        ad.listener = this
        binding.rv.adapter = ad
        return binding.root
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            BeneficiaryListFragment().apply {
                arguments = Bundle().apply {
                }
            }
    }

    override fun onItemSelect(t: Beneficiary) {
        //show details
        NavigationUtils.addFragment(true,parentFragmentManager,BeneficiaryDetailsFragment.newInstance(t), tag = "BEN_DETAIL")
    }
}