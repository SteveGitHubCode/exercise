package com.adeel.adeeldemo.ui.beneficieries

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adeel.adeeldemo.model.Beneficiary
import com.adeel.adeeldemo.repo.DataRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BeneficiaryViewModel @Inject constructor(private val dataRepository: DataRepository) : ViewModel() {
    val beneficiariesList = MutableLiveData<List<Beneficiary>>()
    private var _beneficiaries = ArrayList<Beneficiary>()
    init {
        viewModelScope.launch {
            try {
                val fetchedBeneficiaries = dataRepository.getBeneficiaries()
                _beneficiaries.clear()
                _beneficiaries.addAll(fetchedBeneficiaries)
                beneficiariesList.postValue(_beneficiaries)
            } catch (e: Exception){e.printStackTrace()}
        }
    }
}